package Test_Sem1;
import java.util.Scanner;

public class PublisherApp
{
    public void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("\nIntroduce the name of the editor: ");
        String name= input.next();

        NewsArticle article = new NewsArticle("AI Rising", 800, 200.0, true);
        ProductReview review1 = new ProductReview("New Laptop", 600, 150.0, 5, true);
        ProductReview review2 = new ProductReview("Indie Game", 300, 150.0, 4, false);

        Editor editor= new Editor(name);

        editor.assignContent(article);
        editor.assignContent(review1);
        editor.assignContent(review2);

        System.out.println("\n---The initial portfolio report is: ---");
        editor.printPortfolioReport();

        article.increaseViews(100);
        article.increaseViews(10000, true);//This one should print the "VIRAL ALERT"

        System.out.println("\n--- Content Flagged (Words > 700 OR Read Time < 3 min) ---");
         editor.flagForReview(700, 3.0);
         /*(Article is 800 words, 4.0 min read time)
           (Review 1 is 600 words, 4.0 min read time)
           (Review 2 is 300 words, 2.0 min read time)
           (Verify that this flags article (words > 700) and review2 (time < 3))*/

        System.out.println("\n---The final portfolio report is: ---");
        editor.printPortfolioReport();
        System.out.println("\n---The editor's("+name+") portfolio read-time is: "+editor.getTotalPortfolioReadTime()+" min.");

    }
}
