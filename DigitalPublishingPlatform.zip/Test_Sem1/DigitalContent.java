package Test_Sem1;
//Abstract: Add a comment above your DigitalContent class.
//where: I used abstract to declare an abstract class and abstract methods
//why: I used abstract so that TO the subclasses that will inherit the attributes and methods of DigitalContent
//I can add extra/specific methods and attributes depending on the type of the subclass,
//also they have in common the 2 attributes from here, from the abstract class title and wordCount
// (but they can have extra specific ones for them like: pageViews in NewsArticle etc.)and
// 2 abstract methods(explanation below)

public abstract class DigitalContent
{
    protected String title;
    protected int wordCount;

    public DigitalContent(String title, int wordCount)
    {
        this.title=title;
        this.wordCount=wordCount;
    }

    public String getTitle()
    {
        return title;
    }
    public int getWordCount()
    {
       return wordCount;
    }
    //Abstract Method: Add a comment above one abstract method in DigitalContent.
    //we have 2 abstract methods present in both classes, they do the same thing but in different ways(in general)
    //for example in both classes there is calculateReadTimeMinutes, but it is
    //calculated with their own variables/extra attributes
    public abstract double calculateReadTimeMinutes();
    public abstract String getEditStatus();

}
