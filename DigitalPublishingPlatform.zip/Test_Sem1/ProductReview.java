package Test_Sem1;

public class ProductReview extends DigitalContent
{
    private int ratingStars; //(1-5)
    private double readingSpeedWPM; // (e.g., 150)
    private boolean hasAffiliateLink;

    public ProductReview(String title, int wordCount,  double readingSpeedWPM, int ratingStars, boolean hasAffiliateLink)
    {
        super(title,wordCount);
        this.ratingStars=ratingStars;
        this.readingSpeedWPM=readingSpeedWPM;
        this.hasAffiliateLink=hasAffiliateLink;
    }

    public int getRating()
    {
        return ratingStars;
    }

    @Override
    public double calculateReadTimeMinutes()
    {
        return wordCount/readingSpeedWPM;
    }

    @Override
    public String getEditStatus()
    {
        System.out.println("\nReview ["+title+"]: "+ratingStars+"/5 Stars. ");
        if(ratingStars==5 && hasAffiliateLink)
        {
            return ("Needs Fact-Check");
        }
          else
        {
            return ("Ready for Print");
        }
    }


}
