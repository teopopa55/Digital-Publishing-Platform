package Test_Sem1;

public class Editor
{
    private String editorName;
    private DigitalContent[] portfolio;  //(with a max size of 10)
    private int contentCount;
    private boolean isSeniorEditor;

    public Editor(String editorName)
    {
        this.editorName=editorName;
        portfolio= new DigitalContent[10];
        contentCount=0;
        isSeniorEditor=false;
    }

    public void setSeniorEditor(boolean status)
    {
        isSeniorEditor=status;
    }
    public boolean isSeniorEditor()
    {
        return isSeniorEditor;
    }
    public void assignContent(DigitalContent content)
    {
        if(contentCount<5)
        {
            portfolio[contentCount]=content;
            contentCount++;
        }
        else System.out.println("\nPortfolio is full.");
    }
    public double getTotalPortfolioReadTime()
    {
        double sum=0;
        for(int i=0;i<contentCount;i++)
        {
            sum+=portfolio[i].calculateReadTimeMinutes();
        }
        return sum;
    }
    public void printPortfolioReport()
    {
        for(int i=0;i<contentCount;i++)
        {
            System.out.println(portfolio[i].getEditStatus());
        }
    }
    public void flagForReview(int maxWordCount, double minReadTime)
    {
        for(int i=0;i<contentCount;i++)
        {
            if (portfolio[i].getWordCount()> maxWordCount || portfolio[i].calculateReadTimeMinutes()< minReadTime)
                System.out.println(portfolio[i].getEditStatus());
        }
    }

}
