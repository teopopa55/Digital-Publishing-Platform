package Test_Sem1;
//Inheritance: Add a comment above your NewsArticle or ProductReview class
//where: this was done by using extends DigitalContent
//why: because we want the subclass to:
//NewsArticle-> to reuse and extend the properties and behaviors of Digital Content
//NewsArticle-> inherits fields and methods from Digital Content

public class NewsArticle extends DigitalContent
{
    private int pageViews;
    private double readingSpeedWPM;  //(Words Per Minute, e.g., 200)
    private boolean isBreakingNews;

    public NewsArticle(String title, int wordCount, double readingSpeedWPM, boolean isBreakingNews)
    {
        super(title,wordCount);
        this.pageViews=0;
        this.readingSpeedWPM=readingSpeedWPM;
        this.isBreakingNews=isBreakingNews;
    }

    public void increaseViews(int count)
    {
        pageViews+=count;
    }
    //Overloading: Add a comment above the second increaseViews method in NewsArticle
    //where: by creating 2 functions with the same name, but different parameters in it, in the same class/subclass
    //why: so that we do the same thing but in this one(in general in one out of the 2)
    //we can take into considerations other parameters and do extra things maybe, beside the
    //straight forward thing from the simple one
    public void increaseViews(int count, boolean isViral)
    {
        pageViews+=count;
        if(isViral)
            System.out.println("\nVIRAL ALERT.");

    }
    //Overriding: Add a comment above one @Override method (e.g., calculateReadTimeMinutes in NewsArticle)
    //where:before we wrote the method which is abstract in the parent class
    //why: so that we can use it concerning the other attributes specific to this class
    @Override
    public double calculateReadTimeMinutes()
    {
        return wordCount / readingSpeedWPM;
    }

    @Override
    public String getEditStatus()
    {
        return ("\nArticle ["+title+"] :"+wordCount+" words - "+pageViews+" views ["+"Breaking: "+isBreakingNews+"].");
    }

    @Override
    public int getWordCount()
    {
        return wordCount;
    }

}
